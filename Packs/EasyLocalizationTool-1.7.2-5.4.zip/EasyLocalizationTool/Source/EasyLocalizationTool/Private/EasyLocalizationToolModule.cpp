// Copyright (c) 2025 Damian Nowakowski. All rights reserved.

#include "Modules/ModuleManager.h"

/**
 * Just a module, nothing to see here.
 */

class EASYLOCALIZATIONTOOL_API FEasyLocalizationToolModule : public IModuleInterface
{};

IMPLEMENT_MODULE(FEasyLocalizationToolModule, EasyLocalizationTool)